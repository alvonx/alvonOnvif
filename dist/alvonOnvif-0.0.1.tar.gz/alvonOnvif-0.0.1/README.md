# Onvif Custom 

Features
- Provide rtsp link
- Provide snapshot link
- Loggers